Name: Vishal Vijay Devadiga
Roll Number: CS21BTECH11061
Assignment 1

VC-CS21BTECH11061.cpp is the file containing the code for Vector Clocks
SK-CS21BTECH11061.cpp is the file containing the code for Vector Clocks with SK optimization

Input is supposed to be in "inp-params.txt" and should be of the form given in the assignment document.

To simplify the process of running the code, I have included a Makefile.

To compile the code, use the following command:
make compile

To run the code for VC, use the following command:
make runVC

To run the code for SK, use the following command:
make runSK

To clean the directory, use the following command:
make clean

If the above commands do not work (in case you dont have make installed), use the commands given in the makefile manually.

2 log files are generated: One for all events and one for the data required, that is, total entry sent and total size of messages
